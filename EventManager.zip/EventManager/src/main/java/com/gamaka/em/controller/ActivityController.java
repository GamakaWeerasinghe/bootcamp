package com.gamaka.em.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.gamaka.em.model.Activity;

@Controller
public class ActivityController {
	
	@RequestMapping(value="/greeting")
	
	public String getWelcomeMessage(Model model) {
		
		model.addAttribute("greetingMsg", "welcome to spring MVC");
		return "welcome";
		
	}
	
	@RequestMapping(value="/addActivity")
	public String addActivity(@ModelAttribute("activities") Activity activity)
	{
		System.out.println("Activity is :" + activity.getActivityName());
		
		if (activity.getActivityName() == null){
			return "addActivity";
		} else {
		return "redirect:addSubActivity.html";
		}
		
	}
	
	@RequestMapping (value="/addSubActivity")
	public String addSubActivity(@ModelAttribute ("activities") Activity activity){
		System.out.println("sub activity name is "+ activity.getActivityName());
		return "addActivity";
	}

}
